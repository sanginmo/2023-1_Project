package com.ict.edu_U;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class MainScrean_Infor extends JPanel{
	JPanel super_jp1; // 가장 큰 패널
	
	JPanel air_jp1, air_jp2, air_jp3, air_jp4, 
		   air_jp5, air_jp6, air_jp7, air_jp8,
		   air_jp9; // 공백패널
	
	// 출퇴근 패널, 버튼, 시간
	JPanel big_jp1, // 큰 패널
	       m_jp1, m_jp2,
		   date_jp, gb_jp1, gb_jp2, // 작은 패널
		   group_jp1, group_jp2, group_jp3, group_jp4, group_jp5, // 묶음 패널
		   changTF_jp1, changTF_jp2, changTF_jp3, changTF_jp4; // 텍스트 필드 크기로 인해 만든 패널
	
	// 출퇴근 버튼과 시간을 연동하기 위해 static을 준다.
	// static을 안주게 된다면 WorkPlan이 null이라서?(찾을 수 없어서?) g_time, b_time을 읽을 수 없다고 한다.
	static JButton go, bye;
	static JLabel g_time, b_time;
	
	JLabel ymd_day, d_day;
	
	Font MyFont;
	
	WorkPlan_Infor Work;
	
	public MainScrean_Infor() {
		// 출퇴근
		super_jp1 = new JPanel();
		
		// 공백을 만들기 위한 패널 추가
		air_jp1 = new JPanel();
		air_jp2 = new JPanel();
		air_jp3 = new JPanel();
		air_jp4 = new JPanel();
		air_jp5 = new JPanel();
		air_jp6 = new JPanel();
		air_jp7 = new JPanel();
		air_jp8 = new JPanel();
		air_jp9 = new JPanel();
		
		// 공백패널 크기 조절
		air_jp1.setPreferredSize(new Dimension(200, 75)); // 날짜 위치 변경
		air_jp2.setPreferredSize(new Dimension(160, 0)); // 출근 시간 위치 변경
		air_jp3.setPreferredSize(new Dimension(160, 30)); // 퇴근 시간 위치 변경
		air_jp4.setPreferredSize(new Dimension(0, 0));
		air_jp5.setPreferredSize(new Dimension(50, 10));
		air_jp6.setPreferredSize(new Dimension(0, 100));
		air_jp7.setPreferredSize(new Dimension(50, 0));
		air_jp8.setPreferredSize(new Dimension(50, 60));
		
		// 폰트 설정
		MyFont = new Font("굴림", Font.BOLD, 15);
		
		// 출퇴근패널, 버튼, 시간 만들기
		big_jp1 = new JPanel(); // 출퇴근 묶음
		
		m_jp1 = new JPanel(); // 출근 묶음
		m_jp1.setLayout(new BoxLayout(m_jp1, BoxLayout.PAGE_AXIS));
		
		m_jp2 = new JPanel(); // 퇴근 묶음
		
		gb_jp1 = new JPanel();
		gb_jp1.setLayout(new BoxLayout(gb_jp1, BoxLayout.PAGE_AXIS));
		
		// 값 넣기
		LocalDateTime Datetime = LocalDateTime.now(); // 시간 값 담기
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy. MM. dd"); // 시간값 형태변환
		String DT_Now = Datetime.format(formatter); // 시간 값을 형태변환한 상태로 만든다.
		
		date_jp = new JPanel();
		d_day = new JLabel("<   yyyy. MM. dd");
		d_day.setFont(MyFont);
		d_day.setText("<    " + String.valueOf(DT_Now));
		date_jp.add(d_day);
		
		group_jp1 = new JPanel();
		
		// 출근
		ImageIcon img = new ImageIcon("src\\images\\go_work1.PNG"); // 출근 이미지 넣기
		go = new JButton();
		go.setBackground(Color.WHITE);
		go.setIcon(img);
		go.setPreferredSize(new Dimension(240,130)); // 버튼 크기조절
		group_jp2 = new JPanel();
		
		g_time = new JLabel("hh:mm:ss");
		g_time.setFont(MyFont);
		group_jp3 = new JPanel();
		
		gb_jp2 = new JPanel();
		gb_jp2.setLayout(new BoxLayout(gb_jp2, BoxLayout.PAGE_AXIS));
				
		// 퇴근
		ImageIcon img2 = new ImageIcon("src\\images\\off_work1.PNG"); // 퇴근 이미지 넣기
		bye = new JButton();
		bye.setBackground(Color.WHITE);
		bye.setIcon(img2);
		bye.setPreferredSize(new Dimension(240,130)); // 버튼 크기조절
		bye.setEnabled(false);
		group_jp4 = new JPanel();
		
		b_time = new JLabel("hh:mm:ss");
		b_time.setFont(MyFont);
		group_jp5 = new JPanel();

		// 날짜
		group_jp1.add(air_jp1);
		group_jp1.add(date_jp);
		
		// 출근버튼
		group_jp2.add(go);
		
		// 출근체크 시간
		group_jp3.add(g_time);
		group_jp3.add(air_jp2);
				
		// 퇴근버튼
		group_jp4.add(bye);
		
		// 퇴근체크 시간
		group_jp5.add(air_jp3);
		group_jp5.add(b_time);
		
		// 날짜, 출근버튼, 체크
		gb_jp1.add(group_jp1);
		gb_jp1.add(air_jp4);
		gb_jp1.add(group_jp2);
		gb_jp1.add(air_jp5);
		gb_jp1.add(group_jp3);
		
		// 퇴근버튼, 체크
		gb_jp2.add(air_jp6);
		gb_jp2.add(group_jp4);
		gb_jp2.add(air_jp7);
		gb_jp2.add(group_jp5);
		gb_jp2.add(air_jp8);
		
		m_jp1.add(gb_jp1);
		m_jp1.add(gb_jp2);
		
		// 왼쪽 근퇴패널
		big_jp1.add(m_jp1);
		// 패널 테두리 설정
		big_jp1.setBorder(new LineBorder(Color.BLACK));
		
		// 공지사항 클래스를 상속받아보자.
		MS_B_Nofi bnf = new MS_B_Nofi();
		bnf.setBorder(new LineBorder(Color.BLACK));
		
		// 근퇴, 공지사항
		super_jp1.add(big_jp1);
		super_jp1.add(bnf);

//		super_jp1.setBackground(Color.CYAN);
		
		add(super_jp1);
		
		// 출근 버튼액션
		go.addActionListener(new ActionListener() {
			@Override
			// 현재 날짜구하기
			public void actionPerformed(ActionEvent e) {
				LocalTime Datetime = LocalTime.now(); // 시간 값 담기
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); // 시간값 형태변환
				String DT_Now = Datetime.format(formatter); // 시간 값을 형태변환한 상태로 만든다.
				JOptionPane.showMessageDialog(getParent(), "출근체크가 완료되었습니다.");
				g_time.setText(String.valueOf(DT_Now));
				go.setEnabled(false);
				bye.setEnabled(true);
				// 출퇴근 버튼 연동
				Work.g_time.setText(String.valueOf(DT_Now));
				Work.go.setEnabled(false);
				Work.bye.setEnabled(true);
			}
		});
		
		// 퇴근 버튼액션
		bye.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LocalTime Datetime = LocalTime.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				String DT_Now = Datetime.format(formatter);
				JOptionPane.showMessageDialog(getParent(), "퇴근체크가 완료되었습니다.");
				b_time.setText(String.valueOf(DT_Now));
				go.setEnabled(true);
				bye.setEnabled(false);
				// 출퇴근 버튼 연동
				Work.b_time.setText(String.valueOf(DT_Now));
				Work.go.setEnabled(true);
				Work.bye.setEnabled(false);
			}
		});
	}
}