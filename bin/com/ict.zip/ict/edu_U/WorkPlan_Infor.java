package com.ict.edu_U;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.AbstractCellEditor;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

import com.toedter.calendar.JDateChooser;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.AbstractCellEditor;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

import com.toedter.calendar.JDateChooser;

public class WorkPlan_Infor extends JPanel{
	JPanel super_jp1; // 가장 큰 패널
	
	JPanel air_jp1, air_jp2, air_jp3, air_jp4; //공백패널
	
	// 출퇴근 패널, 버튼, 시간
	JPanel big_jp1, // 큰 패널
		   grid_jp1,
		   g_jp1, g_jp2, g_jp3, b_jp1, b_jp2, b_jp3; // 작은 패널
	
	// 메인화면(홈) 버튼과 시간을 연동하기 위해 static을 준다.
	// static을 안주게 된다면 MainScrean이 null이라서?(찾을 수 없어서?) g_time, b_time을 읽을 수 없다고 한다.
	static JButton go, bye;
	static JLabel g_time, b_time; 
	
	// 출퇴근 현황, 관리자
	JPanel big_jp2, // 큰 패널
		   m_jp1, grid_jp2, // 중간패널
		   n_jp1, n_jp2, n_jp3, n_jp4; // 작은 패널
	
	// 테이블
	JPanel t_jp1, t_jp2; // 테이블 패널
	JLabel gb_time;
	JButton s_bt;
	JTable jtb;
	JScrollPane jsp;
	JDateChooser first_dateChooser, last_dateChooser;
	
	Font MyFont;
	
	JCheckBox CB;
	
	MainScrean_Infor home;
	
	public WorkPlan_Infor() {
		// 출퇴근
		super_jp1 = new JPanel();
		super_jp1.setLayout(new BoxLayout(super_jp1, BoxLayout.PAGE_AXIS));
		
		// 공백을 만들기 위한 패널 추가
		air_jp1 = new JPanel();
		air_jp2 = new JPanel();
		air_jp3 = new JPanel();
		air_jp4 = new JPanel();
		
		// 공백패널 크기 조절
		air_jp1.setPreferredSize(new Dimension(10, 0)); // 출근 버튼 앞 간격 조정
		air_jp2.setPreferredSize(new Dimension(78, 0)); // 출 퇴근 버튼 사이 간격 조정
		air_jp3.setPreferredSize(new Dimension(10, 0)); // 조회 버튼 간격 조정
		air_jp4.setPreferredSize(new Dimension(0, 50)); // 출 퇴근 시간, 출퇴근 현황 사이 간격 조정
		
		// 폰트 설정
		MyFont = new Font("굴림", Font.BOLD, 15);
		
		// 출근 패널, 버튼, 시간 만들기
		big_jp1 = new JPanel();

		g_jp1 = new JPanel();
		g_jp2 = new JPanel();
		g_jp3 = new JPanel();
		g_jp3.setLayout(new BoxLayout(g_jp3, BoxLayout.PAGE_AXIS));

		ImageIcon img = new ImageIcon("src\\images\\go_work2.PNG"); // 버튼 이미지 넣기
		go = new JButton();
		go.setBackground(Color.WHITE); // 버튼 배경색
		go.setIcon(img);
		go.setPreferredSize(new Dimension(300,130)); // 버튼 크기조절
		g_time = new JLabel("hh:mm:ss");
		g_time.setFont(MyFont);
		
		g_jp1.add(go);
		g_jp2.add(g_time);
		g_jp3.add(g_jp1);
		g_jp3.add(g_jp2);
		
		// 퇴근 패널, 버튼, 시간 만들기
		b_jp1 = new JPanel();
		b_jp2 = new JPanel();
		b_jp3 = new JPanel();
		b_jp3.setLayout(new BoxLayout(b_jp3, BoxLayout.PAGE_AXIS));
		
		ImageIcon img2 = new ImageIcon("src\\images\\off_work2.PNG"); // 버튼 이미지 넣기
		bye = new JButton();
		bye.setBackground(Color.WHITE); // 버튼 배경색
		bye.setIcon(img2);
		bye.setPreferredSize(new Dimension(300,130)); // 버튼 크기조절
		bye.setEnabled(false);
		b_time = new JLabel("hh:mm:ss");
		b_time.setFont(MyFont);
		
		b_jp1.add(bye);
		b_jp2.add(b_time);
		
		b_jp3.add(b_jp1);
		b_jp3.add(b_jp2);
		
		// 출퇴근 버튼과 시간을 넣을 텍스트 필드를 하나로 합치기
		big_jp1.add(air_jp1);
		big_jp1.add(g_jp3);
		big_jp1.add(air_jp2);
		big_jp1.add(b_jp3);
		big_jp1.setBorder(new EmptyBorder(0, 0, 0, 16)); // 출근버튼, 퇴근버튼 위치 변경
		
		// 출퇴근 현황
		big_jp2 = new JPanel();
		
		n_jp1 = new JPanel();
		n_jp2 = new JPanel();
		n_jp3 = new JPanel();
		n_jp4 = new JPanel();
		
		m_jp1 = new JPanel();
		m_jp1.setLayout(new BoxLayout(m_jp1, BoxLayout.PAGE_AXIS));
		
		// 날짜 캘린더 만들기
		first_dateChooser = new JDateChooser();
		first_dateChooser.setDateFormatString("yyyy/MM/dd");
		first_dateChooser.setBounds(58, 394, 155, 21); // 캘린더 크기 조정인것 같지만 변화가 없음 확인필요
		first_dateChooser.setPreferredSize(new Dimension(110,20)); // 캘린더 텍스트 길이 조정
		
		last_dateChooser = new JDateChooser();
		last_dateChooser.setDateFormatString("yyyy/MM/dd");
		last_dateChooser.setBounds(58, 394, 155, 21); // 캘린더 크기 조정인것 같지만 변화가 없음 확인필요
		last_dateChooser.setPreferredSize(new Dimension(110,20)); // 캘린더 텍스트 길이 조정
		
		s_bt = new JButton("조회");
		
		// 테이블을 만들기
		t_jp1 = new JPanel();
		t_jp2 = new JPanel();
		
		String[] columName = {"일 자", "이 름", "출근시간", "퇴근시간", "출근현황", "퇴근현황"};
		Object[][] WP_data = {
				{"2022. 01. 01", "둘리", "09:00:00", "10:00:00", "", ""},
				{"2022. 03. 01", "희동이", "hh:MM:ss", "hh:MM:ss", "", ""},
				{"2022. 05. 01", "마이콜", "hh:MM:ss", "hh:MM:ss", "", ""},
				{"2022. 07. 01", "도우너", "hh:MM:ss", "hh:MM:ss", "", ""},
				{"2022. 09. 01", "또치", "hh:MM:ss", "hh:MM:ss", "", ""},
				{"2022. 12. 12", "고길동", "00:00:00", "23:59:59", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""},
				{"", "", "", "", "", ""}
		};
		
		jtb = new JTable(WP_data, columName);
		// 테이블 내용, 정렬기능
		// 중앙 정렬변수를 만들자
		DefaultTableCellRenderer Center = new DefaultTableCellRenderer();
		Center.setHorizontalAlignment(JLabel.CENTER);
				
		// 셀의 넓이를 지정하고 정렬하자
		jtb.getColumn("일 자").setCellRenderer(Center);
		jtb.getColumn("이 름").setCellRenderer(Center);
		jtb.getColumn("출근시간").setCellRenderer(Center);
		jtb.getColumn("퇴근시간").setCellRenderer(Center);
		jtb.getColumn("출근현황").setCellRenderer(Center);
		jtb.getColumn("퇴근현황").setCellRenderer(Center);
		
//		 // 테이블 내 체크박스를 만들어보자
		jtb.getColumnModel().getColumn(4).setCellRenderer(new CheckBox());
		jtb.getColumnModel().getColumn(4).setCellEditor(new CheckBox());
		jtb.getColumnModel().getColumn(5).setCellRenderer(new CheckBox());
		jtb.getColumnModel().getColumn(5).setCellEditor(new CheckBox());
		
		
		jtb.setAutoCreateRowSorter(true); // 정렬기능
		jtb.getTableHeader().setReorderingAllowed(false); // 테이블 해더이동 금지
		jtb.getTableHeader().setResizingAllowed(false); // 테이블 크기 조절 금지
		jtb.setEnabled(false); // 테이블 셀 수정 금지
		
		jsp = new JScrollPane(jtb); // JScrollPanel을 사용하지 않으면 헤더가 보이지 않는다.
		jsp.setPreferredSize(new Dimension(700,247)); // 테이블 크기조절
		t_jp1.add(jsp);
		t_jp2.add(t_jp1);
		
		// 출퇴근 현황 라벨
		gb_time = new JLabel("출퇴근 현황  ");
		gb_time.setFont(MyFont);
		n_jp1.add(gb_time);
		n_jp1.setBorder(new EmptyBorder(0, 0, 0, 608)); // 출퇴근 현황 라벨 위치 변경
		
		n_jp2.add(first_dateChooser);
		n_jp2.add(new JLabel("          ~          "));
        n_jp2.add(last_dateChooser);
        n_jp2.add(air_jp3);
		n_jp2.add(s_bt);
		n_jp2.setBorder(new EmptyBorder(0, 0, 0, 323)); // 출퇴근 현황 위치 변경
		n_jp3.add(t_jp2);
		
		// 관리자 버튼 합치기
		grid_jp2 = new JPanel(new GridLayout(0, 1));
		n_jp4.add(grid_jp2);
		n_jp4.setBorder(new EmptyBorder(0, 486, 0, 0)); // 관리자 버튼 위치 변경
		
		m_jp1.add(n_jp1);
		m_jp1.add(n_jp2);
		m_jp1.add(n_jp3);
		m_jp1.add(n_jp4);

		// 출퇴근 현황 패널을 하나로 합치기
		big_jp2.add(m_jp1);
		
		// 완성한 출퇴근버튼 패널, 시간과 현황 패널을 합치기
		super_jp1.add(big_jp1);
		super_jp1.add(air_jp4);
		super_jp1.add(big_jp2);
		super_jp1.setBorder(new EmptyBorder(50, 30 ,50, 30)); // 최종 패널 위치 지정
		
		add(super_jp1);
		
		// 출근 버튼액션
		go.addActionListener(new ActionListener() {
			@Override
			// 현재 날짜구하기
			public void actionPerformed(ActionEvent e) {
				LocalTime Datetime = LocalTime.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				String DT_Now = Datetime.format(formatter);
				JOptionPane.showMessageDialog(getParent(), "출근체크가 완료되었습니다."); // 팝업창
				g_time.setText(String.valueOf(DT_Now)); // 현재 시간을 라벨에 넣기
				go.setEnabled(false);
				bye.setEnabled(true);
				// 메인화면(홈) 버튼과 연동
				home.g_time.setText(String.valueOf(DT_Now));
				home.go.setEnabled(false);
				home.bye.setEnabled(true);
			}
		});
		
		// 퇴근 버튼액션
		bye.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LocalTime Datetime = LocalTime.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				String DT_Now = Datetime.format(formatter);
				JOptionPane.showMessageDialog(getParent(), "퇴근체크가 완료되었습니다.");
				b_time.setText(String.valueOf(DT_Now));
				go.setEnabled(true);
				bye.setEnabled(false);
				home.b_time.setText(String.valueOf(DT_Now));
				home.go.setEnabled(true);
				home.bye.setEnabled(false);
			}
		});
		
		s_bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try { // try catch를 if문처럼 사용하여 시간값이 null일때 오류 메세지 출력
				// 날짜 값을 "yyyy/MM/dd."로 출력되게 변환
				SimpleDateFormat fom = new SimpleDateFormat("yyyy/MM/dd"); 
				String f_ymd = fom.format(first_dateChooser.getDate());
				String l_ymd = fom.format(last_dateChooser.getDate());
				
				int compare = f_ymd.compareTo(l_ymd);
				
				TableModel model = jtb.getModel();
				
				if(compare > 0) { // 시작시간이 끝 시간보다 클 경우
					JOptionPane.showMessageDialog(getParent(), "시작 시간이 끝 시간보다 큽니다." +
					  		  					  "\n" + "다시 확인해 주세요.");
					
				} else if(compare < 0 || compare == 0) {
					System.out.println("시작시간과 끝 시간을 조회");
					for (int i = 0; i < model.getColumnCount(); i++) {
						String aa = "";
						Object val = model.getValueAt(0, 1);
						aa = aa + " " + val;
					}
					
				} else { // 예상치 못한 오류를 위해 추가
					JOptionPane.showMessageDialog(getParent(), "다시 확인해 주세요.");
				}
				
				} catch (Exception e2) {
					// 시작 시간 또는 끝 시간을 안넣었을때 출력
					JOptionPane.showMessageDialog(getParent(),"시작 시간 또는 끝 시간을 확인해 주세요");
				}
			}
		});
	}
	
	 // 체크박스 클래스를 만들자
	class CheckBox extends AbstractCellEditor implements TableCellEditor, TableCellRenderer{
		JCheckBox JCB;

		public CheckBox() {
			JCB = new JCheckBox();
			
			JCB.addActionListener(e -> {
				System.out.println(jtb.getValueAt(jtb.getSelectedRow(),2)); // 불러올 값
			});
		}
		
		@Override
		public Object getCellEditorValue() {
			return null;
		}

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			return JCB;
		}

		@Override
		public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
				int column) {
			return JCB;
		}
	}
}