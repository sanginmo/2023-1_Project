package com.ict.edu_U;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class MS_B_Nofi extends JPanel{
	JPanel box,
    a, b, c, d, e, f, g, h, i,
    jpa_1, jpa_2, jpa_3, jpa_4, jpa_5,
	   jpb_1, jpb_2, jpb_3, jpb_4, jpb_5,
	   jpc_1, jpc_2, jpc_3, jpc_4, jpc_5,
	   jpd_1, jpd_2, jpd_3, jpd_4, jpd_5,
	   jpe_1, jpe_2, jpe_3, jpe_4, jpe_5,
	   jpf_1, jpf_2, jpf_3, jpf_4, jpf_5,
	   jpg_1, jpg_2, jpg_3, jpg_4, jpg_5,
	   jph_1, jph_2, jph_3, jph_4, jph_5,
	   jpi_1, jpi_2, jpi_3, jpi_4, jpi_5,
	   line_1, line_1a, line_2, line_2a, line_3, line_3a,
	   line_4, line_4a,	line_5, line_5a, line_6, line_6a,
	   line_7, line_7a, line_8, line_8a,
	   Notice_jp, air_jp1; // 내가 추가한 것

JLabel
jlba_1, jlba_2, jlba_3, jlba_4, jlba_5,
jlbb_1, jlbb_2, jlbb_3, jlbb_4, jlbb_5,
jlbc_1, jlbc_2, jlbc_3, jlbc_4, jlbc_5,
jlbd_1, jlbd_2, jlbd_3, jlbd_4, jlbd_5,
jlbe_1, jlbe_2, jlbe_3, jlbe_4, jlbe_5,
jlbf_1, jlbf_2, jlbf_3, jlbf_4, jlbf_5,
jlbg_1, jlbg_2, jlbg_3, jlbg_4, jlbg_5,
jlbh_1, jlbh_2, jlbh_3, jlbh_4, jlbh_5,
jlbi_1, jlbi_2, jlbi_3, jlbi_4, jlbi_5,

NT; // 내가 추가한것

Font myFont_menubar, myFont_important, myFont_basic, MY_basic;

LineBorder lb;

public MS_B_Nofi() {
//	setBackground(Color.black); // 배경색
	
	// 추후에는 boardList를 이용해서 자료를 가져와야 한다
	// 우선은 모양만
	// 1. boxlayout을 만들어보자
	box = new JPanel();
	box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));

	// Font & LineBorder를 만들어 놓자
	myFont_menubar = new Font("굴림", Font.BOLD, 15);
	myFont_important = new Font("굴림", Font.BOLD, 15);
	myFont_basic = new Font("굴림", Font.BOLD, 13);
	
	// 내가 만든 폰트
	MY_basic = new Font("굴림", Font.BOLD, 30);

	lb = new LineBorder(Color.BLACK); // 색과 두께가 같다면 하나만 생성하면 모두 적용가능하다
	

	// 2. boxlayout 맨 상단창인 a를 만들어보자
	a = new JPanel();
	
	jpa_1 = new JPanel();
	jlba_1 = new JLabel("순번");
	jlba_1.setFont(myFont_menubar);
	jlba_1.setForeground(Color.BLUE);
	jpa_1.add(jlba_1);
	jpa_1.setPreferredSize(new Dimension(100, 30));
	
	jpa_2 = new JPanel();
	jlba_2 = new JLabel("제목");
	jlba_2.setFont(myFont_menubar);
	jlba_2.setForeground(Color.BLUE);
	jpa_2.add(jlba_2);
	jpa_2.setPreferredSize(new Dimension(250, 30));
	
//	jpa_3 = new JPanel();
//	jlba_3 = new JLabel("작성자");
//	jlba_3.setFont(myFont_menubar);
//	jlba_3.setForeground(Color.BLUE);
//	jpa_3.add(jlba_3);
//	jpa_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpa_4 = new JPanel();
//	jlba_4 = new JLabel("작성일");
//	jlba_4.setFont(myFont_menubar);
//	jlba_4.setForeground(Color.BLUE);
//	jpa_4.add(jlba_4);
//	jpa_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpa_5 = new JPanel();
//	jlba_5 = new JLabel("조회수");
//	jlba_5.setFont(myFont_menubar);
//	jlba_5.setForeground(Color.BLUE);
//	jpa_5.add(jlba_5);
//	jpa_5.setPreferredSize(new Dimension(100, 30));
	
	jpa_1.setBorder(lb);
	a.add(jpa_1);
	jpa_2.setBorder(lb);
	a.add(jpa_2);
//	jpa_3.setBorder(lb);
//	a.add(jpa_3);
//	jpa_4.setBorder(lb);
//	a.add(jpa_4);
//	jpa_5.setBorder(lb);
//	a.add(jpa_5);

	
	// 3. 순번, 작성일, 조회수 는 출력만 제목과 작성자는 클릭해야하는데 우선 모양만
	
	b = new JPanel();

	jpb_1 = new JPanel();
	jlbb_1 = new JLabel(" 주요공지 ");
	jlbb_1.setFont(myFont_important);
	jlbb_1.setForeground(Color.RED);
	jpb_1.add(jlbb_1);
	jpb_1.setPreferredSize(new Dimension(100, 25));

	jpb_2 = new JPanel();
	jlbb_2 = new JLabel(" 카타르 월드컵 기념 신입사원 모집 ");
	jlbb_2.setFont(myFont_basic);
	jlbb_2.setForeground(Color.BLACK);
	jpb_2.add(jlbb_2);
	jpb_2.setPreferredSize(new Dimension(250, 25));
	
//	jpb_3 = new JPanel();
//	jlbb_3 = new JLabel(" 이훈 ");
//	jlbb_3.setFont(myFont_basic);
//	jlbb_3.setForeground(Color.BLACK);
//	jpb_3.add(jlbb_3);
//	jpb_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpb_4 = new JPanel();
//	jlbb_4 = new JLabel(" 22.11.16 ");
//	jlbb_4.setFont(myFont_basic);
//	jlbb_4.setForeground(Color.BLACK);
//	jpb_4.add(jlbb_4);
//	jpb_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpb_5 = new JPanel();
//	jlbb_5 = new JLabel(" 85 ");
//	jlbb_5.setFont(myFont_basic);
//	jlbb_5.setForeground(Color.BLACK);
//	jpb_5.add(jlbb_5);
//	jpb_5.setPreferredSize(new Dimension(100, 30));
	
	b.add(jpb_1);
	b.add(jpb_2);
//	b.add(jpb_3);
//	b.add(jpb_4);
//	b.add(jpb_5);
	
	// 4. 밑줄을 만들어보자
	
	line_1 = new JPanel();

	line_1a = new JPanel();
	line_1a.add(new JLabel(" --------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_1a.setPreferredSize(new Dimension(355, 20));
	
	line_1.add(line_1a);
	
	
	// =============================================================================
	// 3~4를 반복
	
	c = new JPanel();

	jpc_1 = new JPanel();
	jlbc_1 = new JLabel(" 주요공지 ");
	jlbc_1.setFont(myFont_important);
	jlbc_1.setForeground(Color.RED);
	jpc_1.add(jlbc_1);
	jpc_1.setPreferredSize(new Dimension(100, 25));

	jpc_2 = new JPanel();
	jlbc_2 = new JLabel(" 카타르 월드컵 기념 자사주 공모 ");
	jlbc_2.setFont(myFont_basic);
	jlbc_2.setForeground(Color.BLACK);
	jpc_2.add(jlbc_2);
	jpc_2.setPreferredSize(new Dimension(250, 25));
	
//	jpc_3 = new JPanel();
//	jlbc_3 = new JLabel(" 김철수 ");
//	jlbc_3.setFont(myFont_basic);
//	jlbc_3.setForeground(Color.BLACK);
//	jpc_3.add(jlbc_3);
//	jpc_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpc_4 = new JPanel();
//	jlbc_4 = new JLabel(" 22.01.06 ");
//	jlbc_4.setFont(myFont_basic);
//	jlbc_4.setForeground(Color.BLACK);
//	jpc_4.add(jlbc_4);
//	jpc_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpc_5 = new JPanel();
//	jlbc_5 = new JLabel(" 158 ");
//	jlbc_5.setFont(myFont_basic);
//	jlbc_5.setForeground(Color.BLACK);
//	jpc_5.add(jlbc_5);
//	jpc_5.setPreferredSize(new Dimension(100, 30));
	
	c.add(jpc_1);
	c.add(jpc_2);
//	c.add(jpc_3);
//	c.add(jpc_4);
//	c.add(jpc_5);
	
	// 밑줄
	
	line_2 = new JPanel();

	line_2a = new JPanel();
	line_2a.add(new JLabel(" --------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_2a.setPreferredSize(new Dimension(355, 20));
	
	line_2.add(line_2a);
	
	// ================================================================================
	// 5. 일반 공지를 써보자
	
	d = new JPanel();

	jpd_1 = new JPanel();
	jlbd_1 = new JLabel(" 1 ");
	jlbd_1.setFont(myFont_basic);
	jlbd_1.setForeground(Color.BLACK);
	jpd_1.add(jlbd_1);
	jpd_1.setPreferredSize(new Dimension(100, 25));

	jpd_2 = new JPanel();
	jlbd_2 = new JLabel(" 32강 예측 ");
	jlbd_2.setFont(myFont_basic);
	jlbd_2.setForeground(Color.BLACK);
	jpd_2.add(jlbd_2);
	jpd_2.setPreferredSize(new Dimension(250, 25));
	
//	jpd_3 = new JPanel();
//	jlbd_3 = new JLabel(" 맹구 ");
//	jlbd_3.setFont(myFont_basic);
//	jlbd_3.setForeground(Color.BLACK);
//	jpd_3.add(jlbd_3);
//	jpd_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpd_4 = new JPanel();
//	jlbd_4 = new JLabel(" 22.05.06 ");
//	jlbd_4.setFont(myFont_basic);
//	jlbd_4.setForeground(Color.BLACK);
//	jpd_4.add(jlbd_4);
//	jpd_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpd_5 = new JPanel();
//	jlbd_5 = new JLabel(" 5558 ");
//	jlbd_5.setFont(myFont_basic);
//	jlbd_5.setForeground(Color.BLACK);
//	jpd_5.add(jlbd_5);
//	jpd_5.setPreferredSize(new Dimension(100, 30));
	
	d.add(jpd_1);
	d.add(jpd_2);
//	d.add(jpd_3);
//	d.add(jpd_4);
//	d.add(jpd_5);
	
	// 밑줄
	
	line_3 = new JPanel();

	line_3a = new JPanel();
	line_3a.add(new JLabel(" --------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_3a.setPreferredSize(new Dimension(355, 20));
	
	line_3.add(line_3a);
	
	// ===============================================================================
	// 일반공지 반복
	
	e = new JPanel();

	jpe_1 = new JPanel();
	jlbe_1 = new JLabel(" 2 ");
	jlbe_1.setFont(myFont_basic);
	jlbe_1.setForeground(Color.BLACK);
	jpe_1.add(jlbe_1);
	jpe_1.setPreferredSize(new Dimension(100, 25));

	jpe_2 = new JPanel();
	jlbe_2 = new JLabel(" 16강 예측 ");
	jlbe_2.setFont(myFont_basic);
	jlbe_2.setForeground(Color.BLACK);
	jpe_2.add(jlbe_2);
	jpe_2.setPreferredSize(new Dimension(250, 25));
	
//	jpe_3 = new JPanel();
//	jlbe_3 = new JLabel(" 신짱구 ");
//	jlbe_3.setFont(myFont_basic);
//	jlbe_3.setForeground(Color.BLACK);
//	jpe_3.add(jlbe_3);
//	jpe_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpe_4 = new JPanel();
//	jlbe_4 = new JLabel(" 22.07.06 ");
//	jlbe_4.setFont(myFont_basic);
//	jlbe_4.setForeground(Color.BLACK);
//	jpe_4.add(jlbe_4);
//	jpe_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpe_5 = new JPanel();
//	jlbe_5 = new JLabel(" 45558 ");
//	jlbe_5.setFont(myFont_basic);
//	jlbe_5.setForeground(Color.BLACK);
//	jpe_5.add(jlbe_5);
//	jpe_5.setPreferredSize(new Dimension(100, 30));
	
	e.add(jpe_1);
	e.add(jpe_2);
//	e.add(jpe_3);
//	e.add(jpe_4);
//	e.add(jpe_5);
	
	// 밑줄
	
	line_4 = new JPanel();

	line_4a = new JPanel();
	line_4a.add(new JLabel(" -------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_4a.setPreferredSize(new Dimension(355, 20));
	
	line_4.add(line_4a);

	// ========================================================================
	// 일반공지 반복
	
	f = new JPanel();

	jpf_1 = new JPanel();
	jlbf_1 = new JLabel(" 3 ");
	jlbf_1.setFont(myFont_basic);
	jlbf_1.setForeground(Color.BLACK);
	jpf_1.add(jlbf_1);
	jpf_1.setPreferredSize(new Dimension(100, 25));

	jpf_2 = new JPanel();
	jlbf_2 = new JLabel(" 8강 예측 ");
	jlbf_2.setFont(myFont_basic);
	jlbf_2.setForeground(Color.BLACK);
	jpf_2.add(jlbf_2);
	jpf_2.setPreferredSize(new Dimension(250, 25));
	
//	jpf_3 = new JPanel();
//	jlbf_3 = new JLabel(" 신짱아 ");
//	jlbf_3.setFont(myFont_basic);
//	jlbf_3.setForeground(Color.BLACK);
//	jpf_3.add(jlbf_3);
//	jpf_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpf_4 = new JPanel();
//	jlbf_4 = new JLabel(" 21.01.06 ");
//	jlbf_4.setFont(myFont_basic);
//	jlbf_4.setForeground(Color.BLACK);
//	jpf_4.add(jlbf_4);
//	jpf_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpf_5 = new JPanel();
//	jlbf_5 = new JLabel(" 555 ");
//	jlbf_5.setFont(myFont_basic);
//	jlbf_5.setForeground(Color.BLACK);
//	jpf_5.add(jlbf_5);
//	jpf_5.setPreferredSize(new Dimension(100, 30));
	
	f.add(jpf_1);
	f.add(jpf_2);
//	f.add(jpf_3);
//	f.add(jpf_4);
//	f.add(jpf_5);
	
	// 밑줄
	
	line_5 = new JPanel();

	line_5a = new JPanel();
	line_5a.add(new JLabel(" -------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_5a.setPreferredSize(new Dimension(355, 20));
	
	line_5.add(line_5a);

	// ========================================================================
	// 일반공지 반복
	
	g = new JPanel();

	jpg_1 = new JPanel();
	jlbg_1 = new JLabel(" 4 ");
	jlbg_1.setFont(myFont_basic);
	jlbg_1.setForeground(Color.BLACK);
	jpg_1.add(jlbg_1);
	jpg_1.setPreferredSize(new Dimension(100, 25));

	jpg_2 = new JPanel();
	jlbg_2 = new JLabel(" 4강 예측 ");
	jlbg_2.setFont(myFont_basic);
	jlbg_2.setForeground(Color.BLACK);
	jpg_2.add(jlbg_2);
	jpg_2.setPreferredSize(new Dimension(250, 25));
	
//	jpg_3 = new JPanel();
//	jlbg_3 = new JLabel(" 봉미선 ");
//	jlbg_3.setFont(myFont_basic);
//	jlbg_3.setForeground(Color.BLACK);
//	jpg_3.add(jlbg_3);
//	jpg_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpg_4 = new JPanel();
//	jlbg_4 = new JLabel(" 20.03.06 ");
//	jlbg_4.setFont(myFont_basic);
//	jlbg_4.setForeground(Color.BLACK);
//	jpg_4.add(jlbg_4);
//	jpg_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpg_5 = new JPanel();
//	jlbg_5 = new JLabel("789 ");
//	jlbg_5.setFont(myFont_basic);
//	jlbg_5.setForeground(Color.BLACK);
//	jpg_5.add(jlbg_5);
//	jpg_5.setPreferredSize(new Dimension(100, 30));
	
	g.add(jpg_1);
	g.add(jpg_2);
//	g.add(jpg_3);
//	g.add(jpg_4);
//	g.add(jpg_5);
	
	// 밑줄
	
	line_6 = new JPanel();

	line_6a = new JPanel();
	line_6a.add(new JLabel(" -------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_6a.setPreferredSize(new Dimension(355, 20));
	
	line_6.add(line_6a);

	// ========================================================================
	// 일반공지 반복
	
	h = new JPanel();

	jph_1 = new JPanel();
	jlbh_1 = new JLabel(" 5 ");
	jlbh_1.setFont(myFont_basic);
	jlbh_1.setForeground(Color.BLACK);
	jph_1.add(jlbh_1);
	jph_1.setPreferredSize(new Dimension(100, 25));

	jph_2 = new JPanel();
	jlbh_2 = new JLabel(" 카타르 월드컵 3&4위전 예측 이벤트 ");
	jlbh_2.setFont(myFont_basic);
	jlbh_2.setForeground(Color.BLACK);
	jph_2.add(jlbh_2);
	jph_2.setPreferredSize(new Dimension(250, 25));
	
//	jph_3 = new JPanel();
//	jlbh_3 = new JLabel(" 신형식 ");
//	jlbh_3.setFont(myFont_basic);
//	jlbh_3.setForeground(Color.BLACK);
//	jph_3.add(jlbh_3);
//	jph_3.setPreferredSize(new Dimension(100, 30));
//	
//	jph_4 = new JPanel();
//	jlbh_4 = new JLabel(" 19.07.30 ");
//	jlbh_4.setFont(myFont_basic);
//	jlbh_4.setForeground(Color.BLACK);
//	jph_4.add(jlbh_4);
//	jph_4.setPreferredSize(new Dimension(100, 30));
//	
//	jph_5 = new JPanel();
//	jlbh_5 = new JLabel(" 2651 ");
//	jlbh_5.setFont(myFont_basic);
//	jlbh_5.setForeground(Color.BLACK);
//	jph_5.add(jlbh_5);
//	jph_5.setPreferredSize(new Dimension(100, 30));
	
	h.add(jph_1);
	h.add(jph_2);
//	h.add(jph_3);
//	h.add(jph_4);
//	h.add(jph_5);
	
	// 밑줄
	
	line_7 = new JPanel();

	line_7a = new JPanel();
	line_7a.add(new JLabel(" -------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_7a.setPreferredSize(new Dimension(355, 20));
	
	line_7.add(line_7a);
	
	// ========================================================================
	// 일반공지 반복
	
	i = new JPanel();

	jpi_1 = new JPanel();
	jlbi_1 = new JLabel(" 6 ");
	jlbi_1.setFont(myFont_basic);
	jlbi_1.setForeground(Color.BLACK);
	jpi_1.add(jlbi_1);
	jpi_1.setPreferredSize(new Dimension(100, 25));

	jpi_2 = new JPanel();
	jlbi_2 = new JLabel(" 카타르 월드컵 결승 예측 이벤트 ");
	jlbi_2.setFont(myFont_basic);
	jlbi_2.setForeground(Color.BLACK);
	jpi_2.add(jlbi_2);
	jpi_2.setPreferredSize(new Dimension(250, 25));
	
//	jpi_3 = new JPanel();
//	jlbi_3 = new JLabel(" 흰둥이 ");
//	jlbi_3.setFont(myFont_basic);
//	jlbi_3.setForeground(Color.BLACK);
//	jpi_3.add(jlbi_3);
//	jpi_3.setPreferredSize(new Dimension(100, 30));
//	
//	jpi_4 = new JPanel();
//	jlbi_4 = new JLabel(" 19.05.06 ");
//	jlbi_4.setFont(myFont_basic);
//	jlbi_4.setForeground(Color.BLACK);
//	jpi_4.add(jlbi_4);
//	jpi_4.setPreferredSize(new Dimension(100, 30));
//	
//	jpi_5 = new JPanel();
//	jlbi_5 = new JLabel(" 7887 ");
//	jlbi_5.setFont(myFont_basic);
//	jlbi_5.setForeground(Color.BLACK);
//	jpi_5.add(jlbi_5);
//	jpi_5.setPreferredSize(new Dimension(100, 30));
	
	i.add(jpi_1);
	i.add(jpi_2);
//	i.add(jpi_3);
//	i.add(jpi_4);
//	i.add(jpi_5);
	
	// 밑줄
	
	line_8 = new JPanel();

	line_8a = new JPanel();
	line_8a.add(new JLabel(" -------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "---------------------------------------------------"
			+ "--------------------------------------- "));
	line_8a.setPreferredSize(new Dimension(355, 20));
	
	line_8.add(line_8a);
			
	// ========================================================================	
	
	// 내가 추가한 것
	Notice_jp = new JPanel();
	air_jp1 = new JPanel();
	air_jp1.setPreferredSize(new Dimension(250, 25));
//	Notice_jp.add(new JLabel("Notice"));
	NT = new JLabel("Notice");
	NT.setFont(MY_basic);
	Notice_jp.add(NT);
	Notice_jp.add(air_jp1);
	box.add(Notice_jp);
	
	// 기존 것
	box.add(a);
	box.add(b);
	box.add(line_1);
	box.add(c);
	box.add(line_2);
	box.add(d);
	box.add(line_3);
	box.add(e);
	box.add(line_4);
	box.add(f);
	box.add(line_5);
	box.add(g);
	box.add(line_6);
	box.add(h);
	box.add(line_7);
	box.add(i);
	box.add(line_8);
	
	
	this.add(box);
	
}
}