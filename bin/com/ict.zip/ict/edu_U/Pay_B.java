package com.ict.edu_U;

public class Pay_B {

	public static void main(String[] args) {

		int pay = 0;   // 기본급
		int allowance = 0; // 직책수당
		double bonus = 100000 ; // 식대
		double nation =4.50; // 국민연금
		double health =3.495; // 건강보험
		double employ =0.90; // 고용보험
		int income = 0; // 소득세
		int people = 0; // 주민세
		
		String name = null;
		
		if (name.equals("사원")) {
			
			
		} else if (name.equals("대리")) {
			
			
		} else if (name.equals("과장")) {

			
		} else if (name.equals("부장")) {

			
		}
	}

		
}


