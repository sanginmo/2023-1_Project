package com.ict.edu_D;

import java.io.Serializable;

public class Pay_VO implements Serializable {

	// members에서 이름
	private String USERNAME;
	// info에서 직급 부서
	private String DIVISION, JPOSITION;
	// 급여
	private String cOMID, basic_1, job_1, extend_1, holiday, bonus, guitar, lunch, traffic, welfare, NULL1, NULL2,
			salary, income, citizen, ins, pension, cottage, health, NULL3, NULL4, NULL5, NULL6, subtract, TOTAL;
	
	
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getDIVISION() {
		return DIVISION;
	}
	public void setDIVISION(String dIVISION) {
		DIVISION = dIVISION;
	}
	public String getJPOSITION() {
		return JPOSITION;
	}
	public void setJPOSITION(String jPOSITION) {
		JPOSITION = jPOSITION;
	}
	public String getcOMID() {
		return cOMID;
	}
	public void setcOMID(String cOMID) {
		this.cOMID = cOMID;
	}
	public String getBasic_1() {
		return basic_1;
	}
	public void setBasic_1(String basic_1) {
		this.basic_1 = basic_1;
	}
	public String getJob_1() {
		return job_1;
	}
	public void setJob_1(String job_1) {
		this.job_1 = job_1;
	}
	public String getExtend_1() {
		return extend_1;
	}
	public void setExtend_1(String extend_1) {
		this.extend_1 = extend_1;
	}
	public String getHoliday() {
		return holiday;
	}
	public void setHoliday(String holiday) {
		this.holiday = holiday;
	}
	public String getBonus() {
		return bonus;
	}
	public void setBonus(String bonus) {
		this.bonus = bonus;
	}
	public String getGuitar() {
		return guitar;
	}
	public void setGuitar(String guitar) {
		this.guitar = guitar;
	}
	public String getLunch() {
		return lunch;
	}
	public void setLunch(String lunch) {
		this.lunch = lunch;
	}
	public String getTraffic() {
		return traffic;
	}
	public void setTraffic(String traffic) {
		this.traffic = traffic;
	}
	public String getWelfare() {
		return welfare;
	}
	public void setWelfare(String welfare) {
		this.welfare = welfare;
	}
	public String getNULL1() {
		return NULL1;
	}
	public void setNULL1(String nULL1) {
		NULL1 = nULL1;
	}
	public String getNULL2() {
		return NULL2;
	}
	public void setNULL2(String nULL2) {
		NULL2 = nULL2;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getCitizen() {
		return citizen;
	}
	public void setCitizen(String citizen) {
		this.citizen = citizen;
	}
	public String getIns() {
		return ins;
	}
	public void setIns(String ins) {
		this.ins = ins;
	}
	public String getPension() {
		return pension;
	}
	public void setPension(String pension) {
		this.pension = pension;
	}
	public String getCottage() {
		return cottage;
	}
	public void setCottage(String cottage) {
		this.cottage = cottage;
	}
	public String getHealth() {
		return health;
	}
	public void setHealth(String health) {
		this.health = health;
	}
	public String getNULL3() {
		return NULL3;
	}
	public void setNULL3(String nULL3) {
		NULL3 = nULL3;
	}
	public String getNULL4() {
		return NULL4;
	}
	public void setNULL4(String nULL4) {
		NULL4 = nULL4;
	}
	public String getNULL5() {
		return NULL5;
	}
	public void setNULL5(String nULL5) {
		NULL5 = nULL5;
	}
	public String getNULL6() {
		return NULL6;
	}
	public void setNULL6(String nULL6) {
		NULL6 = nULL6;
	}
	public String getSubtract() {
		return subtract;
	}
	public void setSubtract(String subtract) {
		this.subtract = subtract;
	}
	public String getTOTAL() {
		return TOTAL;
	}
	public void setTOTAL(String tOTAL) {
		TOTAL = tOTAL;
	}

}
